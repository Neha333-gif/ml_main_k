import { HashRouter, Routes, Route, Link } from 'react-router-dom';

function Layout({ children }) {
  return (
    <div>
      <nav style={{ padding: '20px', borderBottom: '1px solid #ddd', display: 'flex', justifyContent: 'space-between' }}>
        <Link to="/" style={{ fontWeight: 'bold', color: '#0077B6', textDecoration: 'none' }}>ML LABS</Link>
        <div style={{ display: 'flex', gap: '20px' }}>
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      {children}
      <footer style={{ padding: '25px', background: '#111827', color: 'white', textAlign: 'center' }}>
        © 2026 ML LABS PRIVATE LIMITED
      </footer>
    </div>
  );
}

function Home() {
  return (
    <Layout>
      <main style={{ minHeight: '70vh', padding: '60px', textAlign: 'center' }}>
        <h1 style={{ fontSize: '48px', color: '#111827' }}>ML LABS PRIVATE LIMITED</h1>
        <p style={{ fontSize: '20px', color: '#555' }}>
          AI, Machine Learning, Data Engineering, Cloud, and Enterprise Software Solutions.
        </p>
        <p style={{ marginTop: '20px' }}>
          #52, 3rd Cross, Aswath Nagar, Marathahalli, Bengaluru, Karnataka-560037
        </p>
      </main>
    </Layout>
  );
}

function About() {
  return (
    <Layout>
      <main style={{ minHeight: '70vh', padding: '60px' }}>
        <h1>About Us</h1>
        <p>ML LABS PRIVATE LIMITED is a Bengaluru-based technology company focused on AI and enterprise software.</p>
      </main>
    </Layout>
  );
}

function Services() {
  return (
    <Layout>
      <main style={{ minHeight: '70vh', padding: '60px' }}>
        <h1>Services</h1>
        <ul>
          <li>AI & Machine Learning</li>
          <li>Data Engineering</li>
          <li>Cloud Solutions</li>
          <li>Enterprise Software</li>
        </ul>
      </main>
    </Layout>
  );
}

function Contact() {
  return (
    <Layout>
      <main style={{ minHeight: '70vh', padding: '60px' }}>
        <h1>Contact</h1>
        <p>#52, 3rd Cross, Aswath Nagar, Marathahalli, Bengaluru, Karnataka-560037</p>
      </main>
    </Layout>
  );
}

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </HashRouter>
  );
}
